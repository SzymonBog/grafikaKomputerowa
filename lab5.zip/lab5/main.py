import numpy as np
from PIL import Image
from PIL import ImageStat as stat
from PIL import ImageChops
from math import pow
import matplotlib.pyplot as plt


# 1a
def statystyki(im, name):
    s = stat.Stat(im)
    print(name)
    print("extrema ", s.extrema)  # max i min
    print("count ", s.count)  # zlicza
    print("mean ", s.mean)  # srednia
    print("median ", s.median)  # mediana
    print("stddev ", s.stddev)  # odchylenie standardowe
    print("\n")
    return s.extrema, s.count, s.mean, s.median, s.stddev

im1 = Image.open('diff.png')
black = np.asarray(im1) * 0
black = Image.fromarray(black)
print(f"b = {black.size} bom = {im1.size}")


dif = ImageChops.difference(im1, black)
im1stat = statystyki(im1, im1.filename)
blackstat = statystyki(black, 'black')
difNames = ['extrema', 'count', 'mean', 'median', 'stddev']

print("obrazy różnią się o tyle:")
for i in range(len(im1stat)):
    if im1stat[i] != blackstat[i]:
        if i != 0:
            print(difNames[i])
            tab = []
            for j in range(len(im1stat[i])):
                tab.append(im1stat[i][j] - blackstat[i][j])
            for j in range(len(tab)):
                print(tab[j])
        else:
            print(difNames[i])
            for j in range(len(im1stat[i])):
                print(f"({im1stat[i][j][0] - blackstat[i][j][0]}, {im1stat[i][j][1] - blackstat[i][j][1]})")

#1b


