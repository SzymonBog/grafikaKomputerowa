import numpy as np
from PIL import Image
from math import pow


# 1
def rysuj_pasy_pionowe_3kolory(w, h, grub):  # funkcja rysuje pasy pionowe na przemian czerwony, zielony, niebieski
    t = (h, w, 3)
    ob = np.ones(t, dtype=np.uint8)
    count = int(w / grub)
    for k in range(count):
        for g in range(grub):
            i = k * grub + g
            for j in range(h):
                ob[j, i] = (pow(g, 2)) % 256


    obn = np.ones(t, dtype=np.uint8)
    count = int(w / grub)
    for k in range(count):
        for g in range(grub):
            i = k * grub + g
            for j in range(h):
                if k % 3 == 0:
                    obn[j, i] = 255 - ob[j,i]
                elif k % 3 == 1:
                    obn[j, i] = 255 - ob[j,i]
                else:
                    obn[j, i] = 255 - ob[j,i]
    obrazki = [ob, obn]
    return obrazki


tab1 = rysuj_pasy_pionowe_3kolory(200, 100, 10)
obraz1 = Image.fromarray(tab1[0])
obraz2 = Image.fromarray(tab1[1])
obraz1.show()
obraz2.show()


def styk(w, h, m, n, kolor):
    ob = np.zeros((h, w, 3), dtype=np.uint8)  # [0-59][0-119]
    ob[:] = kolor[1]

    obn = np.zeros((h, w, 3), dtype=np.uint8)  # [0-59][0-119]
    obn[:] = kolor[1]

    if (0 > m or m > w-1) and (0 > n or n > h-1):
        print(f"index {m} is out of bounds for axis 0 with size {w} and\nindex {n} is out of bounds for axis 0 with size {h}")
    elif 0 > m or m > w-1:
        print(f"index {m} is out of bounds for axis 0 with size {w}")
    elif 0 > n or n > h-1:
        print(f"index {n} is out of bounds for axis 0 with size {h}")
    else:
        print("ok")
        ob[n:h, 0:m] = kolor[0]
        ob[0:n, m:w] = kolor[0]
        for i in range(w):
            for j in range(h):
                obn[j, i] = 255 - ob[j, i]


    ob = Image.fromarray(ob)
    obn = Image.fromarray(obn)
    obrazki = [ob, obn]
    return obrazki


def zad33(w, h, m, n, kolor):
    ob = styk(w, h, m, n, kolor)
    return ob


# zadanie 3 podpunkt 1.3 wywołanie funkcji
kolor = [[0,76,153], [42,185,66]]
obrazki = zad33(120, 60, 80, 10, kolor)
obrazki[0].show()
obrazki[1].show()


# 2
def rysuj_pasy_pionowe_3kolory(w, h, grub, kolor):  # funkcja rysuje pasy pionowe na przemian czerwony, zielony, niebieski
    t = (h, w, 3)
    ob = np.ones(t, dtype=np.uint8)
    count = int(w / grub)
    for k in range(count):
        for g in range(grub):
            i = k * grub + g
            for j in range(h):
                if k % 3 == 0:
                    ob[j,i] = kolor[0]
                elif k % 3 == 1:
                    ob[j,i] = kolor[1]
                else:
                    ob[j,i] = kolor[2]

    obn = np.ones(t, dtype=np.uint8)
    count = int(w / grub)
    for k in range(count):
        for g in range(grub):
            i = k * grub + g
            for j in range(h):
                if k % 3 == 0:
                    obn[j, i] = 255 - ob[j,i]
                elif k % 3 == 1:
                    obn[j, i] = 255 - ob[j,i]
                else:
                    obn[j, i] = 255 - ob[j,i]
    obrazki = [ob, obn]
    return obrazki


kolor = [[153,153,0], [255,0,255], [51,153,255]]
tab1 = rysuj_pasy_pionowe_3kolory(200, 100, 10, kolor)
obraz1 = Image.fromarray(tab1[0])
obraz2 = Image.fromarray(tab1[1])
obraz1.show()
obraz2.show()


def styk(w, h, m, n, kolor):
    ob = np.zeros((h, w, 3), dtype=np.uint8)  # [0-59][0-119]
    ob[:] = kolor[1]

    obn = np.zeros((h, w, 3), dtype=np.uint8)  # [0-59][0-119]
    obn[:] = kolor[1]

    if (0 > m or m > w-1) and (0 > n or n > h-1):
        print(f"index {m} is out of bounds for axis 0 with size {w} and\nindex {n} is out of bounds for axis 0 with size {h}")
    elif 0 > m or m > w-1:
        print(f"index {m} is out of bounds for axis 0 with size {w}")
    elif 0 > n or n > h-1:
        print(f"index {n} is out of bounds for axis 0 with size {h}")
    else:
        print("ok")
        ob[n:h, 0:m] = kolor[0]
        ob[0:n, m:w] = kolor[0]
        for i in range(w):
            for j in range(h):
                obn[j, i] = 255 - ob[j, i]


    ob = Image.fromarray(ob)
    obn = Image.fromarray(obn)
    obrazki = [ob, obn]
    return obrazki


def zad33(w, h, m, n, kolor):
    ob = styk(w, h, m, n, kolor)
    return ob


# zadanie 3 podpunkt 1.3 wywołanie funkcji
kolor = [[0,76,153], [42,185,66]]
obrazki = zad33(120, 60, 80, 10, kolor)
obrazki[0].show()
obrazki[1].show()




