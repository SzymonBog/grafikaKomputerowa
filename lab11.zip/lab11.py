from PIL import Image
import numpy as np
from PIL import ImageOps
import matplotlib.pyplot as plt
from PIL import ImageStat as stat

#plt.switch_backend('TkAgg')

shrek = Image.open("Shrek_Fiona.png")
print(shrek.size)
print(shrek.mode)

tryby = ['1', 'L', 'LA',  'RGB','RGBA','CMYK','YCbCr','HSV',"I",'F']
plt.figure(figsize=(16, 16))
i=1

for t in tryby:
    file_name = "tryb_"+ str(t)
    im_c = shrek.convert(t)
    plt.subplot(4, 3, i)
    plt.title(str(file_name))
    plt.imshow(im_c, "gray")
    plt.axis('off')
    i +=1
    # im_c.show(file_name)

plt.show()
