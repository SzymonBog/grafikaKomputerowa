from PIL import Image
import math


# 1.1
def rysuj_kwadrat_max(obraz, m, n, k):#3razy(3 punkty nie nachodzace)
    obraz1 = obraz.copy()
    pix = obraz.load()
    pix1 = obraz1.load()
    d = int(k/2)
    temp = [0,0,0]
    for a in range(k):
        for b in range(k):
            x = m + a - d
            y = n + b - d
            pixel = pix[x, y]
            temp[0] = max(pixel[0], temp[0])
            temp[1] = max(pixel[1], temp[1])
            temp[2] = max(pixel[2], temp[2])
            #print(temp[0])
    for a in range(k):
        for b in range(k):
            x = m + a - d
            y = n + b - d
            pix1[x, y] = (temp[0], temp[1], temp[2])
    return obraz1


yoda = Image.open("baby_yoda.jpg")
print(f"tryb obrazu {yoda.mode}")
print(f"rozmiar {yoda.size}")
yoda1 = rysuj_kwadrat_max(yoda, 60, 170, 25)
yoda1.show()

# 1.2
def rysuj_kwadrat_min(obraz, m, n, k):#3razy(3 punkty nie nachodzace)
    obraz1 = obraz.copy()
    pix = obraz.load()
    pix1 = obraz1.load()
    d = int(k/2)
    temp = [0,0,0]
    for a in range(k):
        for b in range(k):
            x = m + a - d
            y = n + b - d
            pixel = pix[x, y]
            temp[0] = min(pixel[0], temp[0])
            temp[1] = min(pixel[1], temp[1])
            temp[2] = min(pixel[2], temp[2])
            #print(temp[0])
    for a in range(k):
        for b in range(k):
            x = m + a - d
            y = n + b - d
            pix1[x, y] = (temp[0], temp[1], temp[2])
    return obraz1


yoda = Image.open("baby_yoda.jpg")
print(f"tryb obrazu {yoda.mode}")
print(f"rozmiar {yoda.size}")
yoda2 = rysuj_kwadrat_min(yoda, 60, 170, 25)
yoda2.show()

#2
def zakres(w, h):
    return [(i, j) for i in range(w) for j in range(h)]


def rysuj_kolo(obraz, m_s, n_s, r, kolor):
    obraz1 = obraz.copy()
    w, h = obraz.size
    for i, j in zakres(w, h):
        if (i-m_s)**2+(j-n_s)**2 < r**2: # wzór na koło o środku (m_s, n_s) i promieniu r
            obraz1.putpixel((i,j), kolor)
    return obraz1


yoda3 = rysuj_kolo(yoda, 30, 80, 20, (5,23,246))
yoda3.show()
