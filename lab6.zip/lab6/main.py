import numpy as np
from PIL import Image
from PIL import ImageStat as stat
from PIL import ImageChops
from math import pow
import matplotlib.pyplot as plt


#1
obraz = Image.open("diff.png")
inicjaly = Image.open("inicjaly1.bmp")

#2
def zakres(w, h):
    return [(i, j) for i in range(w) for j in range(h)]
#a
def wstaw_inicjaly(obraz, inicjaly, m, n, kolor):
    obraz1 = obraz.copy()
    w, h = obraz1.size
    w_z, h_z = inicjaly.size
    for i, j in zakres(w_z, h_z):
        if i + m < w and j + n < h:
            if inicjaly.getpixel((i, j)) == 0:
                obraz1.putpixel((i + m, j + n), kolor)
    return obraz1


print(np.asarray(inicjaly).dtype)
zad1 = wstaw_inicjaly(obraz, inicjaly, 270, 32, (255,0,0))
zad1.show()

#b popraw
def wstaw_obraz_z_maska(obraz, maska, m, n, x, y, z):
    obraz1 = obraz.copy()
    w, h = obraz.size
    w0, h0 = maska.size
    for i, j in zakres(w0, h0):
        if i + m < w and j + n < h:
            if maska.getpixel((i, j)) == 0:
                p = obraz.getpixel((i + m, j + n))
                obraz1.putpixel((i + m, j + n), (p[0] + x, p[1] + y, p[2] + z))
    return obraz1

zad2 = wstaw_obraz_z_maska(obraz, inicjaly, 270, 32, 210, 102, 56)
zad2.show()
