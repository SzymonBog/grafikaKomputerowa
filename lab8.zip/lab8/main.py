from PIL import Image
from PIL import ImageFilter
from PIL import ImageChops
import matplotlib.pyplot as plt


def filtruj(obraz, kernel, scale):  # sprawdzic/poprawic
    #obraz.filter(ImageFilter.Kernel(size=(3,3), kernel=kernel, scale=scale, offset=0)) zamiast tego \|/
    arr = obraz.load()
    w, h = obraz.size
    arr = list(arr)
    for i in range(h):
        for j in range(w):
            print(arr[i*3+j][0] * kernel[(i+j)%9])
            #arr[i, j][0] = arr[i, j][0] * kernel[(i+j)%9]
    arr.show()


obraz = Image.open("obraz.png")
obraz1 = obraz.copy()
#obraz.show()
#1
ker = (-1, -1, -1, -1, 8, -1, -1, -1, -1)
filtruj(obraz1, ker, 1)

#2
obraz1 = obraz.filter(ImageFilter.BLUR)
obraz1.show()

